# KR*ERP GitHub Setup

1. Create a new GitHub repository (e.g. `kr-erp`).
2. Extract this folder and push it to GitHub using git commands.
3. GitHub Actions will automatically build an Android AAB.

## Steps:
git init
git remote add origin https://github.com/USERNAME/kr-erp.git
git add .
git commit -m "init ERP"
git push -u origin master

4. Go to GitHub → Actions tab → download artifact `app-release.aab`.
