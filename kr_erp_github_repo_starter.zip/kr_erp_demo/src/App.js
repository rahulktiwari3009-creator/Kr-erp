import React from "react";

function App() {
  return (
    <div style={{ textAlign: "center", marginTop: "50px" }}>
      <h1>Welcome to KR*ERP</h1>
      <p>Basic starter React App for ERP system.</p>
    </div>
  );
}

export default App;